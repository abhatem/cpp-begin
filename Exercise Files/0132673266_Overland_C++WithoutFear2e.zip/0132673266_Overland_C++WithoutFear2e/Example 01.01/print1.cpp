#include <iostream>
using namespace std;

int main() {
     cout << "Never fear, C++ is here! ";
     system("PAUSE");
     return 0;
}
