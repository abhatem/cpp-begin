#include <iostream>
using namespace std;

int main() {

// Declare n as a floating-pt variable.

    double  n;

// Prompt and input value of n.

    cout << "Input a number and press ENTER: ";
    cin >> n;

// Calculate and output the square.

    cout << "The square is: " << n * n;

    return 0;
}
